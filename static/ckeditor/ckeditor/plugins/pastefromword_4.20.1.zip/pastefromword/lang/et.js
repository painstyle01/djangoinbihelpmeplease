/*
Copyright (c) 2003-2022, CKSource Holding sp. z o.o. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'pastefromword', 'et', {
	confirmCleanup: 'Tekst, mida tahad asetada näib pärinevat Wordist. Kas tahad selle enne asetamist puhastada?',
	error: 'Asetatud andmete puhastamine ei olnud sisemise vea tõttu võimalik',
	title: 'Asetamine Wordist',
	toolbar: 'Asetamine Wordist'
} );
