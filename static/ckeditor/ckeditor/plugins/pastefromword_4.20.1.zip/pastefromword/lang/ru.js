/*
Copyright (c) 2003-2022, CKSource Holding sp. z o.o. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'pastefromword', 'ru', {
	confirmCleanup: 'Текст, который вы желаете вставить, по всей видимости, был скопирован из Word. Следует ли очистить его перед вставкой?',
	error: 'Невозможно очистить вставленные данные из-за внутренней ошибки',
	title: 'Вставить из Word',
	toolbar: 'Вставить из Word'
} );
